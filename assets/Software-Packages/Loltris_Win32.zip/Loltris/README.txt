1. Extract the Loltris.zip file you downloaded (MAKE SURE YOU EXTRACT, DONT
JUST DOUBLE CLICK IT)
2. Enter the Loltris directory and double click "Loltris"
3. ???
4. Profit
