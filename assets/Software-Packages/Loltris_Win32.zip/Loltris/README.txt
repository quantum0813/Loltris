1. Extract the Loltris.zip file (make sure you properly extract, don't just
double click it)
2. Enter the extracted Loltris directory and double click "Loltris"
3. ???
4. Profit
